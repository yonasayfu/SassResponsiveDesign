console.log('HELLO');

const test = () => {
	console.log('this is a test');
};
